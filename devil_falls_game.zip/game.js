let dave;
let monsters = [];
let swordSwing = false;
let gravity = 0.6;
let jumpPower = -15;
let floorLevel = 300;
let gameState = 'menu'; // Start at the menu screen

class Player {
    constructor() {
        this.x = 50;
        this.y = floorLevel;
        this.size = 50;
        this.speed = 5;
        this.yVelocity = 0;
        this.isJumping = false;
    }

    show() {
        fill(0, 100, 255);
        rect(this.x, this.y, this.size, this.size);
        textSize(16);
        fill(255);
        text("Hi, I am Dave", this.x, this.y - 10);
    }

    move() {
        if (keyIsDown(LEFT_ARROW)) {
            this.x -= this.speed;
        }
        if (keyIsDown(RIGHT_ARROW)) {
            this.x += this.speed;
        }
    }

    jump() {
        if (!this.isJumping) {
            this.yVelocity = jumpPower;
            this.isJumping = true;
        }
    }

    update() {
        this.y += this.yVelocity;
        this.yVelocity += gravity;

        if (this.y >= floorLevel) {
            this.y = floorLevel;
            this.isJumping = false;
        }
    }

    swingSword() {
        if (swordSwing) {
            fill(255, 0, 0);
            rect(this.x + 30, this.y, 30, 5); // Sword
            for (let i = monsters.length - 1; i >= 0; i--) {
                if (this.x + 60 > monsters[i].x && this.x < monsters[i].x + monsters[i].size) {
                    monsters.splice(i, 1); // Remove monster if hit
                }
            }
        }
    }
}

class Monster {
    constructor(x, y) {
        this.x = x;
        this.y = y;
        this.size = 50;
    }

    show() {
        fill(255, 0, 0);
        rect(this.x, this.y, this.size, this.size);
    }
}

function setup() {
    createCanvas(800, 400);
    dave = new Player();
    monsters.push(new Monster(300, floorLevel), new Monster(500, floorLevel));
}

function draw() {
    if (gameState === 'menu') {
        showMenu();
    } else if (gameState === 'instructions') {
        showInstructions();
    } else if (gameState === 'play') {
        playGame();
    } else if (gameState === 'credits') {
        showCredits();
    }
}

function playGame() {
    background(50, 200, 50);
    dave.show();
    dave.move();
    dave.update();
    dave.swingSword();

    for (let monster of monsters) {
        monster.show();
    }

    fill(100);
    rect(0, floorLevel + 50, width, height - floorLevel - 50);
}

function showMenu() {
    background(0);
    fill(255);
    textSize(32);
    textAlign(CENTER);
    text("Devil Falls", width / 2, height / 2 - 50);
    textSize(24);
    text("Press 'I' for Instructions", width / 2, height / 2);
    text("Press 'Enter' to Start", width / 2, height / 2 + 50);
}

function showInstructions() {
    background(0);
    fill(255);
    textSize(24);
    textAlign(CENTER);
    text("Instructions", width / 2, height / 2 - 100);
    text("Use Arrow Keys to Move", width / 2, height / 2 - 50);
    text("Press Space to Jump", width / 2, height / 2);
    text("Press Z to Swing Sword", width / 2, height / 2 + 50);
    text("Press 'Enter' to Start the Game", width / 2, height / 2 + 100);
}

function showCredits() {
    background(0);
    fill(255);
    textSize(32);
    textAlign(CENTER);
    text("Made by Conor Grosser", width / 2, height / 2);
    text("Character name idea by Rowan", width / 2, height / 2 + 50);
}

function keyPressed() {
    if (gameState === 'menu') {
        if (key === 'I' || key === 'i') {
            gameState = 'instructions';
        } else if (keyCode === ENTER) {
            gameState = 'play';
        }
    } else if (gameState === 'instructions') {
        if (keyCode === ENTER) {
            gameState = 'play';
        }
    } else if (gameState === 'play') {
        if (key === ' ') {
            dave.jump();
        }
        if (key === 'Z' || key === 'z') {
            swordSwing = true;
        }
    }
}

function keyReleased() {
    if (key === 'Z' || key === 'z') {
        swordSwing = false;
    }
}
